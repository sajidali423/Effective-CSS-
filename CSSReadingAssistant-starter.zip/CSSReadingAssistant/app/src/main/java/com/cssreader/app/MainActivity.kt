package com.cssreader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notes
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    HomeScreen(
                        onImport = {
                            // TODO: Connect Android's OpenDocument picker for PDF/DOCX.
                        },
                        onLibrary = {
                            // TODO: Navigate to the local library.
                        },
                        onNotes = {
                            // TODO: Navigate to linked notes.
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(
    onImport: () -> Unit,
    onLibrary: () -> Unit,
    onNotes: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("CSS Reading Assistant", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Read deeply. Understand clearly. Connect ideas.",
                style = MaterialTheme.typography.bodyLarge
            )
        }
        item {
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.CloudUpload, contentDescription = null)
                Text("  Import PDF or DOCX")
            }
        }
        item {
            HomeCard(
                icon = { Icon(Icons.Default.MenuBook, contentDescription = null) },
                title = "My Library",
                description = "Books, chapters and reading progress",
                onClick = onLibrary
            )
        }
        item {
            HomeCard(
                icon = { Icon(Icons.Default.Notes, contentDescription = null) },
                title = "Linked Notes",
                description = "Organize notes by subject and topic",
                onClick = onNotes
            )
        }
        item {
            HomeCard(
                icon = { Icon(Icons.Default.Book, contentDescription = null) },
                title = "Vocabulary & AI",
                description = "Word meanings, Urdu support and explanations",
                onClick = { }
            )
        }
        item {
            Text(
                "Starter build: screens and data services will be added in stages.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun HomeCard(
    icon: @Composable () -> Unit,
    title: String,
    description: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            icon()
            Column(modifier = Modifier.weight(1f).padding(start = 14.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(description, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
