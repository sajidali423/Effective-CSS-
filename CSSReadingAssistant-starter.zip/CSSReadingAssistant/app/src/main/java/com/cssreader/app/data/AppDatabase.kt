package com.cssreader.app.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        BookEntity::class,
        SectionEntity::class,
        SubjectEntity::class,
        TopicEntity::class,
        NoteEntity::class,
        VocabularyEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun studyDao(): StudyDao
}
