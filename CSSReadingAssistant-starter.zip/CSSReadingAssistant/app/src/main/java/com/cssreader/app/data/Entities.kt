package com.cssreader.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "books", indices = [Index("title")])
data class BookEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val author: String? = null,
    val originalUri: String? = null,
    val extractedTextPath: String? = null,
    val fileType: String,
    val importedAt: Long = System.currentTimeMillis(),
    val lastReadSectionId: Long? = null,
    val readingProgress: Float = 0f
)

@Entity(
    tableName = "sections",
    foreignKeys = [ForeignKey(
        entity = BookEntity::class,
        parentColumns = ["id"],
        childColumns = ["bookId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("bookId"), Index("parentSectionId")]
)
data class SectionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bookId: Long,
    val parentSectionId: Long? = null,
    val title: String,
    val orderIndex: Int,
    val startOffset: Int? = null,
    val endOffset: Int? = null
)

@Entity(tableName = "subjects", indices = [Index(value = ["name"], unique = true)])
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(
    tableName = "topics",
    foreignKeys = [ForeignKey(
        entity = SubjectEntity::class,
        parentColumns = ["id"],
        childColumns = ["subjectId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("subjectId"), Index(value = ["subjectId", "name"], unique = true)]
)
data class TopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String
)

@Entity(
    tableName = "notes",
    indices = [Index("subjectId"), Index("topicId"), Index("bookId"), Index("sectionId")]
)
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val subjectId: Long? = null,
    val topicId: Long? = null,
    val bookId: Long? = null,
    val sectionId: Long? = null,
    val quotedText: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "vocabulary",
    indices = [Index("word"), Index("bookId"), Index("topicId")]
)
data class VocabularyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val word: String,
    val partOfSpeech: String? = null,
    val meaningEnglish: String? = null,
    val meaningUrdu: String? = null,
    val exampleSentence: String? = null,
    val synonyms: String? = null,
    val antonyms: String? = null,
    val contextualSentence: String? = null,
    val bookId: Long? = null,
    val sectionId: Long? = null,
    val topicId: Long? = null,
    val savedAt: Long = System.currentTimeMillis()
)
