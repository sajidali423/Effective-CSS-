package com.cssreader.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {
    @Insert
    suspend fun insertBook(book: BookEntity): Long

    @Query("SELECT * FROM books ORDER BY title COLLATE NOCASE")
    fun observeBooks(): Flow<List<BookEntity>>

    @Query("SELECT * FROM books WHERE id = :bookId")
    suspend fun getBook(bookId: Long): BookEntity?

    @Insert
    suspend fun insertSections(sections: List<SectionEntity>)

    @Query("SELECT * FROM sections WHERE bookId = :bookId ORDER BY orderIndex")
    fun observeSections(bookId: Long): Flow<List<SectionEntity>>

    @Insert
    suspend fun insertSubject(subject: SubjectEntity): Long

    @Query("SELECT * FROM subjects ORDER BY name COLLATE NOCASE")
    fun observeSubjects(): Flow<List<SubjectEntity>>

    @Insert
    suspend fun insertTopic(topic: TopicEntity): Long

    @Query("SELECT * FROM topics WHERE subjectId = :subjectId ORDER BY name COLLATE NOCASE")
    fun observeTopics(subjectId: Long): Flow<List<TopicEntity>>

    @Insert
    suspend fun insertNote(note: NoteEntity): Long

    @Update
    suspend fun updateNote(note: NoteEntity)

    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    fun observeNotes(): Flow<List<NoteEntity>>

    @Query("SELECT * FROM notes WHERE topicId = :topicId ORDER BY updatedAt DESC")
    fun observeNotesForTopic(topicId: Long): Flow<List<NoteEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveVocabulary(entry: VocabularyEntity): Long

    @Query("SELECT * FROM vocabulary ORDER BY savedAt DESC")
    fun observeVocabulary(): Flow<List<VocabularyEntity>>

    @Query("SELECT * FROM vocabulary WHERE word LIKE '%' || :query || '%' ORDER BY word")
    fun searchVocabulary(query: String): Flow<List<VocabularyEntity>>
}
