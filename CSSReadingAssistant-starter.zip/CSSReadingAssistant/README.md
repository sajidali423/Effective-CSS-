# CSS Personal Reading Assistant — Android starter

This is the initial project scaffold, not a finished app or a compiled APK.

## Included
- Kotlin + Jetpack Compose home screen
- Android Gradle project structure
- Room data models and DAO for books, sections, subjects, topics, notes, and vocabulary
- Initial dependency declarations

## Planned implementation order
1. Connect Room database and repository layer.
2. Add PDF/DOCX document picker and extraction pipeline.
3. Detect headings and build an editable chapter/section tree.
4. Implement the reading screen with selectable text and saved position.
5. Add English/Urdu dictionary lookups and vocabulary saving.
6. Add a backend-mediated AI explanation endpoint.
7. Build linked notes and subject/topic navigation.
8. Add OCR, backup/export, accessibility, and test coverage.

## Important
- Do not put AI provider API keys inside the Android app. Use a backend service.
- Use Android's Storage Access Framework for user-selected files.
- Keep the original document and extracted text; extraction can be imperfect.
- Scanned PDFs require OCR.
- Verify current dependency versions, Android SDK availability, and library licenses before production use.

## Build
Open this project in an Android-capable build environment with JDK 17 and Android SDK platform 35 installed, then run:

`./gradlew assembleDebug`

The first successful build should produce `app/build/outputs/apk/debug/app-debug.apk`.
